# Eval: happy path

## Setup
Working directory: a fresh copy of the MyClassroomAIbot project, with `local-tools/_nav.js` already present (the canonical version, with the `DEFAULT_APPS` array and `ICONS` table intact).

## Prompt
"Use the teacher-app-builder skill to build me an app that takes a class roster CSV and produces a printable seating-chart card for each student. Use the guided path."

## Expected behavior
1. Skill asks the opener (guided vs. free-prose).
2. Skill asks the five guided questions in order.
3. Skill restates the resolved spec and asks for confirmation.
4. After confirmation, skill generates `local-tools/seating-chart-cards/app.html` and `local-tools/seating-chart-cards/sandbox.csv`.
5. Inline verification check returns `VERIFICATION: PASS`.
6. `local-tools/_nav.js` is edited: a new entry for the seating-chart-cards app is added to the `DEFAULT_APPS` array.

## Pass criteria
- `local-tools/seating-chart-cards/app.html` exists and opens in a browser without console errors.
- `local-tools/_nav.js` `DEFAULT_APPS` array contains a new entry with `id: 'seating-chart-cards'`, a valid `icon` key from the `ICONS` table, and `file: 'seating-chart-cards/app.html'`.
- Every pre-existing entry in `DEFAULT_APPS` is still present, exactly once, unchanged.
- The `ICONS` table and all helper functions in `_nav.js` are unchanged.
- The generated HTML does not contain any of: `localStorage`, `sessionStorage`, `indexedDB`, `fetch(`, `XMLHttpRequest`, `showSaveFilePicker`.
- The CSP meta tag is unchanged from the scaffold base.
- No `local-tools/manifest.json` file is created.
