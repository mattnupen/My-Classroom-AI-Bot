---
name: teacher-app-builder
description: Use when a K-12 teacher wants to build their own offline HTML app for their classroom (e.g., printable cards, sortable rosters, parent-message drafts). Generates a single-file HTML app from a hardened scaffold, enforces four privacy invariants via an inline verification check, and registers the app in local-tools/_nav.js for the AI dashboard. Triggered by "build me an app", "make me a tool", "/teacher-app-builder".
---

# Teacher App-Builder

Help a K-12 teacher build a single-file offline HTML app for their classroom. Every app you produce must satisfy four privacy invariants by construction:

1. Single static HTML file, no build step.
2. No outbound network calls except `https://cdn.sheetjs.com`.
3. No `localStorage` / `sessionStorage` / `indexedDB` of uploaded data.
4. No saving to the filesystem inside the project folder. Output is print or `<a download>` only.

These are enforced by the inline verification check in Step 4 below. Do not skip it. Do not register an app in `_nav.js` if it fails.

## Step 1 — Open the conversation

Follow `references/conversation-flow.md` exactly. Do not invent your own opener. End this step with a confirmed "resolved spec" in the format shown there, and an explicit teacher "yes."

## Step 2 — Generate the app

1. Choose the matching example from `references/examples/`:
   - Output style "Printable cards" → `printable-cards.html`
   - Output style "On-screen sortable list" → `sortable-list.html`
   - Output style "Downloadable CSV" or "On-screen text to copy" → `csv-export.html`
2. Read `references/scaffold-base.html`. Substitute the slots:
   - `{{TITLE}}` → the title from the resolved spec
   - `{{INTRO}}` → a one-sentence description, ending with " — nothing leaves your computer."
   - `{{SHEETJS_SLOT}}` → if the app takes a CSV/XLSX file, replace with `<script src="https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js"></script>`. Otherwise leave the HTML comment as-is.
   - `{{EXTRA_STYLES_SLOT}}` → any per-app CSS additions. Keep small. Do not introduce new CSS variables.
   - `{{BODY_SLOT}}` → the BODY section of the chosen example, adapted to this app's specific fields
   - `{{LOGIC_SLOT}}` → the LOGIC section of the chosen example, adapted to this app's specific fields
3. Write the result to `local-tools/<slug>/app.html`. Create the folder if it doesn't exist.
4. Do not import or include any URL other than the SheetJS CDN. Do not write any `localStorage` / `sessionStorage` / `indexedDB` / `showSaveFilePicker` / `FileSystemFileHandle` / `fetch(` / `XMLHttpRequest` code. If you find yourself wanting to, you are wrong — re-read the invariants.

## Step 3 — Generate the sandbox file (only if the app takes a data file)

If the app's input is a CSV or XLSX file, create `local-tools/<slug>/sandbox.csv` (always CSV, even if the real input will be XLSX — CSV is easier to read).

- Use 12 fictional students. Generate names that are obviously fake but plausible (e.g., "Avery Brookfield", "Marcus Whitlow"). Generate fresh names each time — do not reuse a fixed roster across apps.
- Populate columns specific to the app's needs.
- Vary the data so the teacher can see how the app handles different cases (e.g., one student with zero issues, one with many).

If the app does not take a data file, skip this step entirely. The nav entry has no sandbox field — the file's presence in the app folder is the only signal.

## Step 4 — Verify (THE GATE)

Apply the invariants checklist in `references/verification-prompt.md` to the file you just wrote. This is an inline self-check — you (the model running the skill) read your own generated `app.html` and verify each invariant explicitly. There is no separate reviewer.

Read `references/verification-prompt.md` and follow it step by step. Output `VERIFICATION: PASS` or `VERIFICATION: FAIL` according to the checklist.

- On `VERIFICATION: PASS`: continue to Step 5.
- On `VERIFICATION: FAIL`: tell the teacher the gate failed, show each violation in plain language, and stop. **Do not register the app in `_nav.js`.** Leave the generated `app.html` in place so the teacher can inspect it. If a compliant alternative exists (e.g., the teacher asked for localStorage; offer the download-and-reload pattern), propose it instead of just refusing.

## Step 5 — Build the nav entry (in memory, not as a file)

The sidebar nav entry uses this exact shape — five fields, nothing more. It is a JavaScript object literal (not JSON), matching the entries already in `DEFAULT_APPS`:

```js
  { id: '<slug>', label: '<title from resolved spec>', file: '<slug>/app.html', description: '<problem_solved from resolved spec, one short sentence>', icon: '<icon-key>' }
```

Notes:
- `id` is the slug from the conversation-flow rules. Lowercase, dash-separated.
- `file` is relative to `local-tools/` (matches how the existing flat tools are listed), so `<slug>/app.html` since the skill always writes apps inside a per-app folder.
- `icon` must be one of the keys defined in the `ICONS` table at the top of `_nav.js` (currently: `home`, `award`, `pulse`, `megaphone`, `chart`, `mail`, `users`, `idcard`, `gear`). Default to `gear` when nothing else fits. Do not add new icon keys — the set is intentionally small. See `references/nav-rebuild.md` for guidance on choosing.
- No `sandbox_path`, no `built_on` — the nav entry is intentionally minimal. The sandbox file (if generated in Step 3) lives next to `app.html` in the same folder; the teacher discovers it there. Do not invent extra fields.
- Do NOT write this entry to a sidecar `app.json` file, and do NOT write a `manifest.json` file. The entry lives only in the `DEFAULT_APPS` array inside `local-tools/_nav.js`.

## Step 6 — Register in `_nav.js`

Follow `references/nav-rebuild.md` exactly. The registration is a Read → Edit flow using only the standard Read and Edit tools — **no shell**, so it works equivalently in Claude Code and Cowork. If an entry with the same `id` already exists, replace it; otherwise insert a new entry just before the closing `];` of the `DEFAULT_APPS` array. Every other entry and every other part of `_nav.js` (the `ICONS` table, helper functions, sidebar rendering code) is preserved.

Verify the post-condition (Read `_nav.js` back; confirm the new entry's `id` is present in `DEFAULT_APPS` and every other entry is still intact) before reporting success.

## Step 7 — Hand off

Tell the teacher:

> "Done. Your new app is at `local-tools/<slug>/app.html`. To use it, double-click any tool in `local-tools/` (or `ClassAI-dashboard.html`) — your new app is now in the sidebar on every page. {{If sandbox: 'I also generated a fictional `sandbox.csv` in the same folder — drag it in first to confirm everything works before you point it at your real data.'}}"

Do **not** open the app yourself. Do not invoke it via Bash. The teacher launches it.
