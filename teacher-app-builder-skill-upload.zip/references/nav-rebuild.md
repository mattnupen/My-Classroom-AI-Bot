# Nav Registration (registering a new app in `_nav.js`)

After the gate passes, register the new app in `local-tools/_nav.js` by adding (or replacing) an entry in the `DEFAULT_APPS` array. Every tool page and the dashboard load `_nav.js` via `<script src="./_nav.js">`, so adding an entry here makes the new app appear in the sidebar everywhere.

**No shell, no JSON parsing** — uses only the standard Read and Edit tools.

## Preconditions

- The new entry has already been built in memory in SKILL.md Step 5, shaped as a JS object literal:
  ```js
  { id: '<slug>', label: '<title>', file: '<slug>/app.html', description: '<one-sentence>', icon: '<icon-key>' }
  ```
- `icon` must be one of the keys defined in the `ICONS` table at the top of `_nav.js`. See "Choosing an icon" below.

## Steps

1. **Read** `local-tools/_nav.js` using the Read tool. Find the `const DEFAULT_APPS = [` block and the closing `];`.

2. **Check for duplicates.** Scan the existing entries for one with the same `id` as the new entry.

3. **If an entry with that `id` already exists:**
   - Use the Edit tool to replace that one line with the new entry line.
   - The `old_string` must be the complete existing line (including leading whitespace and trailing comma if any) so the Edit matches uniquely.
   - The `new_string` is the new entry line at the same indentation, with the same trailing comma (or none) as the original line.

4. **If no entry with that `id` exists (this is the common case):**
   - Use the Edit tool to add a comma to the current last entry and insert the new entry on the following line.
   - The `old_string` is the current last entry line *without* a trailing comma (look at the existing array — the last entry has no comma, every entry before it does).
   - The `new_string` is the same line *with* a trailing comma added, then a newline, then the new entry line — no trailing comma on the new line, since it is now the last.
   - Match the existing 2-space indentation exactly.

5. **Preserve everything else** — the `ICONS` table above the array, the helper functions below it (`defaultState`, `loadState`, `saveState`, etc.), the sidebar-rendering code, and every other `DEFAULT_APPS` entry must round-trip untouched. Never use Write to replace the whole file; always use Edit on the smallest possible span.

## Verify before reporting success

After editing, Read `local-tools/_nav.js` back. Confirm all of these:

- The new entry's `id` appears in the `DEFAULT_APPS` array exactly once.
- Every previously-listed app `id` still appears exactly once.
- The `DEFAULT_APPS` array is still syntactically valid: each entry on its own line, trailing commas only between entries (no comma on the final entry), closing `];` intact.
- The `ICONS` table is unchanged.
- The helper functions and sidebar-rendering code below the array are unchanged.

If any check fails, do not tell the teacher the build succeeded. Tell them what went wrong, and leave the generated `app.html` in place so they can investigate.

## Reference shape

A valid entry, written at the same 2-space indentation as the existing array:

```js
  { id: 'seating-chart', label: 'Seating Chart', file: 'seating-chart/app.html', description: 'Print a seating chart from the roster', icon: 'gear' }
```

## Choosing an icon

The `icon` value must be one of the keys already defined in the `ICONS` table at the top of `_nav.js`. Current keys and what they fit:

- `idcard` — anything per-student / per-card (printable cards, ID-style outputs)
- `mail` — anything that drafts messages to send
- `megaphone` — announcements, broadcasts
- `chart` — analytics, sortable per-student stats
- `pulse` — aggregate snapshots, summaries
- `users` — anything about groups, pairs, or roster organization
- `award` — anything celebratory (badges, certificates)
- `home` — reserved for the dashboard; do not reuse
- `gear` — default fallback when nothing else fits

Do not add new icon keys; the available set is intentionally small. If nothing fits well, use `gear`.
